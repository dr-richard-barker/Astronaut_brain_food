#!/usr/bin/env python3
"""
Script 09: Neurological figures (data-driven).

Produces 5 data-driven matplotlib figures:
  Fig 1: Brain volcano plot
  Fig 2: GSEA pathway theme dotplot
  Fig 3: Top 15 brain LINCS reversers bar chart
  Fig 4: Nutrient PK radar chart
  Fig 8: Brain-focused recipe nutrient coverage heatmap

All saved as SVG + PNG to results/figures/.
Mechanism figures (5, 6, 7) are generated separately via GenerateImage.
"""

import os
import re
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
from matplotlib import rcParams
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap

# ── Phylo brand colors ──
PHYLO_GOLD = "#D4A04A"
PHYLO_BLUE = "#0279EE"
PHYLO_GREEN = "#75A025"
PHYLO_ORANGE = "#FF9400"
PHYLO_PINK = "#FD9BED"
PHYLO_BLACK = "#000000"
PHYLO_BG = "#FAF9F3"

# ── Font settings ──
rcParams['font.family'] = ['Liberation Sans', 'Arimo', 'DejaVu Sans']
rcParams['svg.fonttype'] = 'none'
rcParams['axes.spines.top'] = False
rcParams['axes.spines.right'] = False

PROJ = "/workspace/astronaut-opposite-forcing"
FIG_DIR = os.path.join(PROJ, "results", "figures")
os.makedirs(FIG_DIR, exist_ok=True)


def save_fig(fig, name):
    """Save figure as SVG and PNG."""
    svg_path = os.path.join(FIG_DIR, f"{name}.svg")
    png_path = os.path.join(FIG_DIR, f"{name}.png")
    fig.savefig(svg_path, format="svg", bbox_inches="tight", facecolor="white")
    fig.savefig(png_path, format="png", dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    # Verify PNG
    from PIL import Image
    img = Image.open(png_path)
    print(f"  Saved {name}.svg + {name}.png ({img.size[0]}x{img.size[1]})")


# ──────────────────────────────────────────────────────────
# Fig 1: Brain volcano plot
# ──────────────────────────────────────────────────────────
def fig1_volcano():
    print("Fig 1: Brain volcano plot...")
    meta = pd.read_csv(os.path.join(PROJ, "data/processed/meta_analysis_brain_full.csv"))
    sig = pd.read_csv(os.path.join(PROJ, "data/processed/consensus_signature_brain.csv"))
    merged = meta.merge(sig[['gene_id', 'human_symbol', 'mouse_symbol', 'core']],
                        on='gene_id', how='left', suffixes=('', '_sig'))

    merged['neg_log10_padj'] = -np.log10(merged['padj'].clip(lower=1e-10))
    merged['gene_label'] = merged.apply(
        lambda r: r['human_symbol'] if pd.notna(r['human_symbol'])
        else (r['mouse_symbol'] if pd.notna(r['mouse_symbol']) else ''), axis=1)

    # Categories
    consensus = merged[merged['consensus'] == True]
    core = merged[merged['core'] == True]
    background = merged[~merged['consensus']]

    fig, ax = plt.subplots(figsize=(8, 7))

    # Background genes
    ax.scatter(background['pooled_log2FC'], background['neg_log10_padj'],
               s=8, c='#D9D6CF', alpha=0.4, edgecolors='none', label='All genes')
    # Consensus (non-core)
    cons_noncore = consensus[consensus['core'] != True]
    up = cons_noncore[cons_noncore['direction'] == 'up']
    dn = cons_noncore[cons_noncore['direction'] == 'down']
    ax.scatter(up['pooled_log2FC'], up['neg_log10_padj'],
               s=25, c=PHYLO_ORANGE, alpha=0.7, edgecolors='white', linewidth=0.3,
               label=f'Consensus up ({len(up)})')
    ax.scatter(dn['pooled_log2FC'], dn['neg_log10_padj'],
               s=25, c=PHYLO_BLUE, alpha=0.7, edgecolors='white', linewidth=0.3,
               label=f'Consensus down ({len(dn)})')
    # Core genes
    ax.scatter(core['pooled_log2FC'], core['neg_log10_padj'],
               s=60, c=PHYLO_GOLD, alpha=0.9, edgecolors=PHYLO_BLACK, linewidth=0.8,
               label=f'Core ({len(core)})', zorder=5)

    # Label top genes by |log2FC| among those with readable symbols
    labelable = consensus[consensus['gene_label'].str.len() > 0]
    labelable = labelable[labelable['gene_label'].str.startswith('ENSMUSG') == False]
    labelable = labelable[labelable['gene_label'].str.startswith('Gm') == False]
    top_labels = labelable.reindex(
        (labelable['neg_log10_padj'] + labelable['pooled_log2FC'].abs()).sort_values(ascending=False).index
    ).head(8)
    for _, r in top_labels.iterrows():
        ax.annotate(r['gene_label'], (r['pooled_log2FC'], r['neg_log10_padj']),
                    fontsize=7, fontweight='bold', xytext=(5, 5), textcoords='offset points',
                    color=PHYLO_BLACK)

    ax.axhline(-np.log10(0.05), color='gray', linestyle='--', linewidth=0.7, alpha=0.5)
    ax.axvline(0, color='gray', linestyle='-', linewidth=0.5, alpha=0.3)
    ax.set_xlabel('Pooled log$_2$ fold change (spaceflight vs. ground)', fontsize=11)
    ax.set_ylabel('-log$_{10}$(adjusted p-value)', fontsize=11)
    ax.set_title('Brain transcriptomic response to spaceflight', fontsize=13, fontweight='bold')
    ax.legend(loc='upper right', fontsize=8, framealpha=0.9)

    fig.tight_layout()
    save_fig(fig, "fig1_brain_volcano")


# ──────────────────────────────────────────────────────────
# Fig 2: GSEA pathway theme dotplot
# ──────────────────────────────────────────────────────────
def fig2_gsea_dotplot():
    print("Fig 2: GSEA pathway theme dotplot...")
    themes = pd.read_csv(os.path.join(PROJ, "results/tables/brain_pathway_themes.csv"))

    # For each theme, show top 3 pathways by |NES|, plus theme summary
    theme_order = [
        "Mitochondrial dysfunction", "Protein homeostasis", "DNA damage & repair",
        "Cell cycle suppression", "Immune & inflammatory response",
        "Metabolic reprogramming", "Synaptic & neuronal signaling",
        "Developmental signaling", "Circadian & cholesterol dysregulation",
        "Apoptosis & cell death"
    ]

    # Select top 3 by |NES| per theme
    rows = []
    for theme in theme_order:
        sub = themes[themes['theme'] == theme].copy()
        sub['abs_NES'] = sub['NES'].abs()
        top = sub.nlargest(3, 'abs_NES')
        for _, r in top.iterrows():
            # Clean pathway name
            pw = r['pathway'].replace('HALLMARK_', '').replace('REACTOME_', '')
            pw = pw.replace('_', ' ').title()
            if len(pw) > 50:
                pw = pw[:47] + '...'
            rows.append({
                'theme': theme,
                'pathway': pw,
                'NES': r['NES'],
                'p.adjust': r['p.adjust'],
                'direction': r['direction'],
            })

    df = pd.DataFrame(rows)

    # Theme colors
    theme_colors = {
        "Mitochondrial dysfunction": PHYLO_BLUE,
        "Protein homeostasis": PHYLO_GREEN,
        "DNA damage & repair": PHYLO_ORANGE,
        "Cell cycle suppression": PHYLO_PINK,
        "Immune & inflammatory response": "#C62828",
        "Metabolic reprogramming": "#6A1B9A",
        "Synaptic & neuronal signaling": "#00838F",
        "Developmental signaling": "#4E342E",
        "Circadian & cholesterol dysregulation": PHYLO_GOLD,
        "Apoptosis & cell death": "#37474F",
    }

    fig, ax = plt.subplots(figsize=(10, 10))
    y_pos = np.arange(len(df))
    colors = [theme_colors[t] for t in df['theme']]
    sizes = -np.log10(df['p.adjust'].clip(lower=1e-10)) * 40 + 30

    # Horizontal bars colored by direction
    bar_colors = [PHYLO_BLUE if n < 0 else PHYLO_ORANGE for n in df['NES']]
    ax.barh(y_pos, df['NES'], color=bar_colors, alpha=0.6, height=0.6, edgecolor='none')
    # Dots for significance
    ax.scatter(df['NES'], y_pos, s=sizes, c=colors, alpha=0.9, edgecolors='white', linewidth=0.5, zorder=5)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(df['pathway'], fontsize=8)
    ax.set_xlabel('Normalized Enrichment Score (NES)', fontsize=11)
    ax.set_title('Brain GSEA pathways by neurological theme', fontsize=13, fontweight='bold')
    ax.axvline(0, color='gray', linewidth=0.5)

    # Theme group labels on right
    prev_theme = None
    group_start = 0
    for i, t in enumerate(df['theme']):
        if t != prev_theme:
            if prev_theme is not None:
                mid = (group_start + i - 1) / 2
                ax.text(1.02, mid, prev_theme, transform=ax.get_yaxis_transform(),
                        fontsize=7, va='center', color=theme_colors[prev_theme], fontweight='bold',
                        rotation=0, ha='left')
            group_start = i
            prev_theme = t
    # Last group
    mid = (group_start + len(df) - 1) / 2
    ax.text(1.02, mid, prev_theme, transform=ax.get_yaxis_transform(),
            fontsize=7, va='center', color=theme_colors[prev_theme], fontweight='bold',
            ha='left')

    # Legend
    up_patch = mpatches.Patch(color=PHYLO_ORANGE, alpha=0.6, label='Upregulated')
    dn_patch = mpatches.Patch(color=PHYLO_BLUE, alpha=0.6, label='Downregulated')
    ax.legend(handles=[up_patch, dn_patch], loc='lower right', fontsize=9)

    ax.invert_yaxis()
    fig.tight_layout()
    save_fig(fig, "fig2_gsea_theme_dotplot")


# ──────────────────────────────────────────────────────────
# Fig 3: Top 15 brain LINCS reversers bar chart
# ──────────────────────────────────────────────────────────
def fig3_lincs_bar():
    print("Fig 3: Top 15 brain LINCS reversers bar chart...")
    lincs = pd.read_csv(os.path.join(PROJ, "results/tables/lincs_brain/tier1_ranking_annotated.csv"))
    top15 = lincs.head(15).copy()

    # Clean compound names
    top15['label'] = top15['compound'].str.replace('_', ' ').str.title()
    # Add phase annotation
    top15['phase_label'] = top15['drh_clinical_phase'].fillna('Unknown')

    # Color by clinical phase
    phase_colors = {
        'Launched': PHYLO_GREEN,
        'Phase 2': PHYLO_BLUE,
        'Phase 1': PHYLO_ORANGE,
        'Phase 3': PHYLO_GOLD,
        'Unknown': '#BDBDBD',
        'nan': '#BDBDBD',
    }
    colors = [phase_colors.get(str(p), '#BDBDBD') for p in top15['phase_label']]

    fig, ax = plt.subplots(figsize=(9, 7))
    y_pos = np.arange(len(top15))
    ax.barh(y_pos, top15['median_z_sum'], color=colors, height=0.6, edgecolor='white', linewidth=0.5)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(top15['label'], fontsize=9)
    ax.set_xlabel('Median connectivity z-sum (negative = reverses signature)', fontsize=10)
    ax.set_title('Top 15 brain LINCS L1000 reversers', fontsize=13, fontweight='bold')
    ax.axvline(0, color='gray', linewidth=0.5)

    # Add z-value labels
    for i, (_, r) in enumerate(top15.iterrows()):
        ax.text(r['median_z_sum'] - 0.15, i, f'{r["median_z_sum"]:.2f}',
                va='center', ha='right', fontsize=8, color='white', fontweight='bold')

    # Add phase labels on right
    for i, phase in enumerate(top15['phase_label']):
        if str(phase) != 'nan':
            ax.text(0.15, i, str(phase), va='center', ha='left', fontsize=7,
                    color='#555555', transform=ax.get_yaxis_transform())

    # Legend
    legend_patches = [mpatches.Patch(color=v, label=k) for k, v in phase_colors.items() if k != 'nan']
    ax.legend(handles=legend_patches, loc='lower right', fontsize=8, title='Clinical phase')

    ax.invert_yaxis()
    fig.tight_layout()
    save_fig(fig, "fig3_lincs_reversers_bar")


# ──────────────────────────────────────────────────────────
# Fig 4: Nutrient PK radar chart
# ──────────────────────────────────────────────────────────
def fig4_pk_radar():
    print("Fig 4: Nutrient PK radar chart...")
    pk = pd.read_csv(os.path.join(PROJ, "results/tables/brain_nutrient_pk_table.csv"))

    # Define scoring axes (0-5 scale based on literature)
    # Axes: BBB penetration, Oral bioavailability, Brain concentration,
    #        Evidence grade, LINCS reversal, Spaceflight relevance
    scores = {
        'Sulforaphane':    {'BBB penetration': 5, 'Oral bioavailability': 5, 'Brain concentration': 4,
                            'Evidence grade': 5, 'LINCS reversal': 4, 'Spaceflight relevance': 5},
        'Curcumin':        {'BBB penetration': 2, 'Oral bioavailability': 1, 'Brain concentration': 1,
                            'Evidence grade': 2, 'LINCS reversal': 4, 'Spaceflight relevance': 3},
        'Luteolin':        {'BBB penetration': 3, 'Oral bioavailability': 3, 'Brain concentration': 3,
                            'Evidence grade': 3, 'LINCS reversal': 4, 'Spaceflight relevance': 4},
        'EGCG':            {'BBB penetration': 4, 'Oral bioavailability': 2, 'Brain concentration': 3,
                            'Evidence grade': 4, 'LINCS reversal': 2, 'Spaceflight relevance': 4},
        'Ascorbic acid':   {'BBB penetration': 5, 'Oral bioavailability': 5, 'Brain concentration': 5,
                            'Evidence grade': 5, 'LINCS reversal': 4, 'Spaceflight relevance': 5},
        'Quercetin':       {'BBB penetration': 4, 'Oral bioavailability': 2, 'Brain concentration': 3,
                            'Evidence grade': 4, 'LINCS reversal': 3, 'Spaceflight relevance': 5},
        'Resveratrol':     {'BBB penetration': 4, 'Oral bioavailability': 1, 'Brain concentration': 2,
                            'Evidence grade': 3, 'LINCS reversal': 2, 'Spaceflight relevance': 4},
    }

    axes = ['BBB penetration', 'Oral bioavailability', 'Brain concentration',
            'Evidence grade', 'LINCS reversal', 'Spaceflight relevance']
    n_axes = len(axes)
    angles = np.linspace(0, 2 * np.pi, n_axes, endpoint=False).tolist()
    angles += angles[:1]  # Close the polygon

    nutrient_colors = {
        'Sulforaphane': PHYLO_GREEN,
        'Curcumin': PHYLO_GOLD,
        'Luteolin': PHYLO_PINK,
        'EGCG': PHYLO_BLUE,
        'Ascorbic acid': PHYLO_ORANGE,
        'Quercetin': '#6A1B9A',
        'Resveratrol': '#C62828',
    }

    fig, ax = plt.subplots(figsize=(9, 9), subplot_kw=dict(polar=True))

    for nutrient, vals in scores.items():
        values = [vals[a] for a in axes]
        values += values[:1]
        color = nutrient_colors[nutrient]
        ax.plot(angles, values, 'o-', linewidth=1.5, markersize=4, color=color, label=nutrient, alpha=0.8)
        ax.fill(angles, values, alpha=0.08, color=color)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(axes, fontsize=9)
    ax.set_ylim(0, 5.5)
    ax.set_yticks([1, 2, 3, 4, 5])
    ax.set_yticklabels(['1', '2', '3', '4', '5'], fontsize=7, color='gray')
    ax.set_title('Nutrient pharmacokinetic profile comparison', fontsize=13, fontweight='bold', pad=20)
    ax.legend(loc='upper right', bbox_to_anchor=(1.35, 1.1), fontsize=8, framealpha=0.9)

    fig.tight_layout()
    save_fig(fig, "fig4_nutrient_pk_radar")


# ──────────────────────────────────────────────────────────
# Fig 8: Brain-focused recipe nutrient coverage heatmap
# ──────────────────────────────────────────────────────────
def fig8_recipe_heatmap():
    print("Fig 8: Recipe nutrient coverage heatmap...")
    recipes = pd.read_csv(os.path.join(PROJ, "results/tables/vegan_recipes_scored.csv"))

    # 10 countermeasure nutrients
    nutrients = ['sulforaphane', 'curcumin', 'ascorbic acid', 'quercetin', 'luteolin',
                 'resveratrol', 'epigallocatechin gallate', 'gingerol', 'allicin', 'lutein']

    # Build presence matrix
    matrix = []
    recipe_names = []
    for _, r in recipes.iterrows():
        targets = str(r['target_nutrients']).lower()
        row = []
        for nut in nutrients:
            row.append(1 if nut in targets else 0)
        matrix.append(row)
        # Shorten recipe name
        name = r['name']
        if len(name) > 35:
            name = name[:32] + '...'
        recipe_names.append(name)

    mat = np.array(matrix)

    fig, ax = plt.subplots(figsize=(10, 8))

    # Custom colormap: white to gold
    cmap = LinearSegmentedColormap.from_list('phylo', ['#FAF9F3', PHYLO_GOLD, PHYLO_ORANGE])

    im = ax.imshow(mat, cmap=cmap, aspect='auto', vmin=0, vmax=1)

    ax.set_xticks(np.arange(len(nutrients)))
    ax.set_xticklabels([n.title() for n in nutrients], rotation=45, ha='right', fontsize=9)
    ax.set_yticks(np.arange(len(recipe_names)))
    ax.set_yticklabels(recipe_names, fontsize=9)

    # Add phase annotation
    phases = recipes['phase'].tolist()
    phase_colors = {'pre_flight': PHYLO_BLUE, 'in_flight': PHYLO_GREEN, 'post_flight': PHYLO_ORANGE}
    for i, phase in enumerate(phases):
        ax.text(-0.8, i, phase.replace('_', ' ').title(), fontsize=7, va='center',
                color=phase_colors.get(phase, 'gray'), fontweight='bold')

    # Add nutrient score as text
    for i, r in enumerate(recipes.iterrows()):
        score = r[1]['nutrient_score']
        ax.text(len(nutrients) + 0.2, i, f'{score}', fontsize=8, va='center', color=PHYLO_BLACK)

    ax.text(len(nutrients) + 0.2, -1.2, 'Score', fontsize=8, va='center', color=PHYLO_BLACK, fontweight='bold')

    # Grid lines
    ax.set_xticks(np.arange(-0.5, len(nutrients), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(recipe_names), 1), minor=True)
    ax.grid(which='minor', color='white', linewidth=1.5)
    ax.tick_params(which='minor', size=0)

    ax.set_title('Vegan recipe nutrient coverage for neuroprotection', fontsize=13, fontweight='bold')
    ax.set_xlabel('Countermeasure nutrient', fontsize=11)

    fig.tight_layout()
    save_fig(fig, "fig8_recipe_nutrient_heatmap")


# ──────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 60)
    print("Script 09: Neurological Figures (data-driven)")
    print("=" * 60)

    fig1_volcano()
    fig2_gsea_dotplot()
    fig3_lincs_bar()
    fig4_pk_radar()
    fig8_recipe_heatmap()

    print("\n" + "=" * 60)
    print("Script 09 (data-driven figures) complete.")
    print("Mechanism figures (5, 6, 7) generated separately via GenerateImage.")
    print("=" * 60)
