#!/usr/bin/env python3
"""
Script 11: Zenodo package assembly for neurological countermeasures analysis.

Assembles all scripts, tables, figures, reports, and metadata into a single
ZIP package for Zenodo deposition.

Output: /mnt/results/astronaut_neurological_zenodo.zip
"""

import os
import subprocess
import zipfile
import shutil
from datetime import datetime

PROJ = "/workspace/astronaut-opposite-forcing"
RESULTS = os.path.join(PROJ, "results")
SCRIPTS = os.path.join(PROJ, "scripts")
DATA = os.path.join(PROJ, "data", "processed")

# Staging directory in /workspace (POSIX, fast)
STAGE = "/workspace/zenodo_stage_neuro"
PKG_NAME = "astronaut_neurological_zenodo"


def stage_file(src, dst_rel, stage_dir):
    """Copy a file to the staging directory using subprocess cp (S3-safe)."""
    dst = os.path.join(stage_dir, dst_rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.exists(src):
        subprocess.run(["cp", src, dst], check=True)
        return True
    return False


def build_zenodo_package():
    print("=" * 60)
    print("Script 11: Zenodo Package Assembly")
    print("=" * 60)

    # Clean and create staging
    if os.path.exists(STAGE):
        shutil.rmtree(STAGE)
    os.makedirs(STAGE)

    pkg_dir = os.path.join(STAGE, PKG_NAME)
    os.makedirs(pkg_dir, exist_ok=True)

    file_count = 0

    # ── 1. Scripts ──
    print("\n1. Staging scripts...")
    script_files = [
        "08_brain_neuro_analysis.py",
        "09_neuro_figures.py",
        "10_neuro_report.py",
        "11_neuro_zenodo.py",
    ]
    for sf in script_files:
        src = os.path.join(SCRIPTS, sf)
        if stage_file(src, f"scripts/{sf}", pkg_dir):
            file_count += 1
            print(f"  + {sf}")

    # Also include original scripts 01-07 for completeness
    for sf in sorted(os.listdir(SCRIPTS)):
        if sf.endswith(".py") and sf not in script_files:
            src = os.path.join(SCRIPTS, sf)
            if stage_file(src, f"scripts/{sf}", pkg_dir):
                file_count += 1
                print(f"  + {sf}")

    # ── 2. Tables ──
    print("\n2. Staging tables...")
    tbl_dir = os.path.join(RESULTS, "tables")
    for tf in sorted(os.listdir(tbl_dir)):
        src = os.path.join(tbl_dir, tf)
        if os.path.isfile(src) and tf.endswith(".csv"):
            if stage_file(src, f"tables/{tf}", pkg_dir):
                file_count += 1
                print(f"  + tables/{tf}")

    # Supplementary tables
    supp_dir = os.path.join(tbl_dir, "brain_supplementary_tables")
    if os.path.isdir(supp_dir):
        for sf in sorted(os.listdir(supp_dir)):
            src = os.path.join(supp_dir, sf)
            if os.path.isfile(src) and sf.endswith(".csv"):
                if stage_file(src, f"tables/brain_supplementary_tables/{sf}", pkg_dir):
                    file_count += 1
                    print(f"  + tables/brain_supplementary_tables/{sf}")

    # LINCS brain subdirectory
    lincs_dir = os.path.join(tbl_dir, "lincs_brain")
    if os.path.isdir(lincs_dir):
        for lf in sorted(os.listdir(lincs_dir)):
            src = os.path.join(lincs_dir, lf)
            if os.path.isfile(src):
                if stage_file(src, f"tables/lincs_brain/{lf}", pkg_dir):
                    file_count += 1
                    print(f"  + tables/lincs_brain/{lf}")

    # ── 3. Figures ──
    print("\n3. Staging figures...")
    fig_dir = os.path.join(RESULTS, "figures")
    # Only stage neurological figures (fig1_brain_volcano, fig2_gsea_theme, etc.)
    neuro_figs = [
        "fig1_brain_volcano.svg", "fig1_brain_volcano.png",
        "fig2_gsea_theme_dotplot.svg", "fig2_gsea_theme_dotplot.png",
        "fig3_lincs_reversers_bar.svg", "fig3_lincs_reversers_bar.png",
        "fig4_nutrient_pk_radar.svg", "fig4_nutrient_pk_radar.png",
        "fig5_spaceflight_brain_mechanism.png",
        "fig6_nutrient_intervention_network.png",
        "fig7_diet_mission_phase.png",
        "fig8_recipe_nutrient_heatmap.svg", "fig8_recipe_nutrient_heatmap.png",
        "figure_legends.md",
    ]
    for ff in neuro_figs:
        src = os.path.join(fig_dir, ff)
        if stage_file(src, f"figures/{ff}", pkg_dir):
            file_count += 1
            print(f"  + figures/{ff}")

    # ── 4. Data (processed) ──
    print("\n4. Staging processed data...")
    data_files = [
        "consensus_signature_brain.csv",
        "meta_analysis_brain_full.csv",
    ]
    for df in data_files:
        src = os.path.join(DATA, df)
        if stage_file(src, f"data/{df}", pkg_dir):
            file_count += 1
            print(f"  + data/{df}")

    # ── 5. Reports ──
    print("\n5. Staging reports...")
    report_files = [
        ("/mnt/results/report_neurological_countermeasures.pdf", "report_neurological_countermeasures.pdf"),
        ("/mnt/results/manuscript_neurological_countermeasures.tex", "manuscript_neurological_countermeasures.tex"),
        ("/mnt/results/README_neurological.md", "README.md"),
        ("/mnt/results/CITATION_neurological.cff", "CITATION.cff"),
        ("/mnt/results/figure_legends.md", "figure_legends.md"),
    ]
    for src, dst_name in report_files:
        if stage_file(src, dst_name, pkg_dir):
            file_count += 1
            print(f"  + {dst_name}")

    # ── 6. Manifest ──
    print("\n6. Creating manifest...")
    manifest_path = os.path.join(pkg_dir, "MANIFEST.txt")
    with open(manifest_path, "w") as f:
        f.write(f"Neurological Countermeasures for Spaceflight\n")
        f.write(f"Zenodo Package Manifest\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total files: {file_count + 1}\n")  # +1 for manifest itself
        f.write(f"\n{'='*60}\n\n")
        f.write("CONTENTS:\n\n")
        f.write("scripts/           - Analysis scripts (01-11)\n")
        f.write("tables/             - Result tables (CSV)\n")
        f.write("  brain_supplementary_tables/ - Supplementary tables S1-S6\n")
        f.write("  lincs_brain/      - LINCS L1000 brain screening results\n")
        f.write("figures/            - Figures (SVG + PNG)\n")
        f.write("data/               - Processed consensus signatures\n")
        f.write("report_neurological_countermeasures.pdf - Full PDF report\n")
        f.write("manuscript_neurological_countermeasures.tex - LaTeX manuscript\n")
        f.write("README.md           - Package overview\n")
        f.write("CITATION.cff        - Citation information\n")
        f.write("figure_legends.md   - Detailed figure legends\n")
        f.write("MANIFEST.txt        - This file\n")
        f.write(f"\n{'='*60}\n\n")
        f.write("KEY ANALYSIS OUTPUTS:\n\n")
        f.write("1. Brain consensus signature: 505 genes (208 up, 297 down, 13 core)\n")
        f.write("   Source: 4 rodent ISS studies (OSD-525, OSD-564, OSD-612, OSD-613)\n")
        f.write("2. GSEA: 550 pathways in 10 neurological themes\n")
        f.write("3. LINCS: 221 brain reverser compounds\n")
        f.write("4. Nutrient PK: 7 nutrients with full pharmacokinetic profiles\n")
        f.write("5. Intervention network: 27 nutrient-pathway edges\n")
        f.write("6. Dietary strategy: 12 vegan recipes across 3 mission phases\n")
    file_count += 1
    print(f"  + MANIFEST.txt")

    # ── 7. Create ZIP ──
    # Write to /workspace first (POSIX), then cp to /mnt/results (S3-safe)
    print(f"\n7. Creating ZIP package ({file_count} files)...")
    zip_workspace = f"/workspace/{PKG_NAME}.zip"
    if os.path.exists(zip_workspace):
        os.remove(zip_workspace)

    with zipfile.ZipFile(zip_workspace, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(pkg_dir):
            for file in sorted(files):
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, pkg_dir)
                arcname = f"{PKG_NAME}/{arcname}"
                zf.write(file_path, arcname)

    zip_size = os.path.getsize(zip_workspace)
    print(f"  ZIP created in workspace: {zip_workspace} ({zip_size / 1024 / 1024:.1f} MB)")

    # Copy to /mnt/results using subprocess cp (S3-safe)
    zip_path = "/mnt/results/astronaut_neurological_zenodo.zip"
    if os.path.exists(zip_path):
        os.remove(zip_path)
    subprocess.run(["cp", zip_workspace, zip_path], check=True)
    print(f"  ZIP copied to results: {zip_path}")

    # Verify ZIP
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = zf.namelist()
        print(f"  Verification: {len(names)} entries in ZIP")
        # Check key files
        key_files = [
            f"{PKG_NAME}/report_neurological_countermeasures.pdf",
            f"{PKG_NAME}/manuscript_neurological_countermeasures.tex",
            f"{PKG_NAME}/README.md",
            f"{PKG_NAME}/CITATION.cff",
            f"{PKG_NAME}/scripts/08_brain_neuro_analysis.py",
            f"{PKG_NAME}/tables/brain_nutrient_pk_table.csv",
            f"{PKG_NAME}/tables/brain_pathway_themes.csv",
            f"{PKG_NAME}/figures/fig1_brain_volcano.png",
        ]
        for kf in key_files:
            if kf in names:
                print(f"    OK: {kf}")
            else:
                print(f"    MISSING: {kf}")

    # Cleanup staging
    shutil.rmtree(STAGE)

    print(f"\n{'='*60}")
    print(f"Script 11 complete.")
    print(f"  Zenodo package: {zip_path}")
    print(f"  Size: {zip_size / 1024 / 1024:.1f} MB")
    print(f"  Files: {file_count}")
    print(f"{'='*60}")


if __name__ == "__main__":
    build_zenodo_package()
