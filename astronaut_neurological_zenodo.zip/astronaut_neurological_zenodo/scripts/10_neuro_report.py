#!/usr/bin/env python3
"""
Script 10: Neurological countermeasures PDF report + LaTeX manuscript.

Generates:
  1. /mnt/results/report_neurological_countermeasures.pdf  (~20-25 pages)
  2. /mnt/results/manuscript_neurological_countermeasures.tex
  3. /mnt/results/README_neurological.md
  4. /mnt/results/CITATION_neurological.cff
"""

import os
import subprocess
import pandas as pd
import numpy as np
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image, KeepTogether, HRFlowable
)
from reportlab.platypus.flowables import Flowable

# ── Phylo brand colors ──
PHYLO_BLACK = HexColor("#000000")
PHYLO_WARM_GRAY = HexColor("#ECE9E2")
PHYLO_OFF_WHITE = HexColor("#FAF9F3")
PHYLO_GOLD = HexColor("#D4A04A")
PHYLO_BLUE = HexColor("#0279EE")
PHYLO_GREEN = HexColor("#75A025")
PHYLO_ORANGE = HexColor("#FF9400")
PHYLO_PINK = HexColor("#FD9BED")
HEADING_COLOR = HexColor("#111111")
BODY_TEXT = HexColor("#2C2A26")
MUTED_TEXT = HexColor("#8A8378")
CAPTION_TEXT = MUTED_TEXT
TABLE_HEADER_BG = PHYLO_GOLD
TABLE_HEADER_FG = HexColor("#FFFFFF")
TABLE_ALT_ROW = HexColor("#F9F7F3")
TABLE_BORDER = HexColor("#D5CFC5")
DIVIDER_COLOR = PHYLO_GOLD
CALLOUT_BG = PHYLO_OFF_WHITE
CALLOUT_BORDER = PHYLO_GOLD

FONT_HEADING = "Helvetica-Bold"
FONT_BODY = "Helvetica"
FONT_ITALIC = "Helvetica-Oblique"
FONT_MONO = "Courier"

PROJ = "/workspace/astronaut-opposite-forcing"
FIG_DIR = os.path.join(PROJ, "results", "figures")
TBL_DIR = os.path.join(PROJ, "results", "tables")
DATA_DIR = os.path.join(PROJ, "data", "processed")

# ── Styles ──
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="ReportTitle", fontName=FONT_HEADING,
    fontSize=24, textColor=HEADING_COLOR, spaceBefore=0, spaceAfter=6, leading=30))
styles.add(ParagraphStyle(name="Subtitle", fontName=FONT_BODY,
    fontSize=12, textColor=PHYLO_GOLD, spaceAfter=4))
styles.add(ParagraphStyle(name="Attribution", fontName=FONT_ITALIC,
    fontSize=10, textColor=MUTED_TEXT, spaceAfter=8))
styles.add(ParagraphStyle(name="SectionHead", fontName=FONT_HEADING,
    fontSize=16, textColor=HEADING_COLOR, spaceBefore=24, spaceAfter=10, leading=20))
styles.add(ParagraphStyle(name="SubHead", fontName=FONT_HEADING,
    fontSize=12, textColor=HEADING_COLOR, spaceBefore=14, spaceAfter=6, leading=16))
styles.add(ParagraphStyle(name="Body", fontName=FONT_BODY,
    fontSize=10.5, textColor=BODY_TEXT, alignment=TA_JUSTIFY, spaceAfter=8, leading=15))
styles.add(ParagraphStyle(name="Caption", fontName=FONT_ITALIC,
    fontSize=9, textColor=CAPTION_TEXT, alignment=TA_CENTER, spaceBefore=4, spaceAfter=14, leading=12))
styles.add(ParagraphStyle(name="TableCell", fontName=FONT_BODY,
    fontSize=8.5, textColor=BODY_TEXT, alignment=TA_LEFT, leading=11))
styles.add(ParagraphStyle(name="TableCellSmall", fontName=FONT_BODY,
    fontSize=7.5, textColor=BODY_TEXT, alignment=TA_LEFT, leading=10))
styles.add(ParagraphStyle(name="TableHeader", fontName=FONT_HEADING,
    fontSize=8.5, textColor=TABLE_HEADER_FG, alignment=TA_LEFT, leading=11))
styles.add(ParagraphStyle(name="CalloutText", fontName=FONT_BODY,
    fontSize=10, textColor=BODY_TEXT, alignment=TA_JUSTIFY, spaceAfter=4, leading=14))
styles.add(ParagraphStyle(name="BulletItem", fontName=FONT_BODY,
    fontSize=10.5, textColor=BODY_TEXT, alignment=TA_LEFT, spaceAfter=4, leading=14,
    leftIndent=20, bulletIndent=8))


def page_header_footer(canvas, doc):
    canvas.saveState()
    w, h = letter
    canvas.setFont(FONT_BODY, 9)
    canvas.setFillColor(MUTED_TEXT)
    canvas.drawString(60, h - 40, "Neurological Countermeasures for Spaceflight")
    canvas.setStrokeColor(PHYLO_GOLD)
    canvas.setLineWidth(1)
    canvas.line(60, h - 48, w - 60, h - 48)
    canvas.setStrokeColor(TABLE_BORDER)
    canvas.setLineWidth(0.75)
    canvas.line(60, 40, w - 60, 40)
    canvas.setFont(FONT_BODY, 8)
    canvas.setFillColor(MUTED_TEXT)
    canvas.drawCentredString(w / 2, 26, f"Page {doc.page}")
    canvas.restoreState()


def divider(width=480):
    return HRFlowable(width=width, thickness=1, color=DIVIDER_COLOR, spaceAfter=10, spaceBefore=4)


def callout_box(text, width=460):
    data = [[Paragraph(text, styles["CalloutText"])]]
    t = Table(data, colWidths=[width])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), CALLOUT_BG),
        ("BOX", (0, 0), (-1, -1), 0.5, TABLE_BORDER),
        ("LINEBEFORE", (0, 0), (0, -1), 3, PHYLO_GOLD),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 14),
        ("RIGHTPADDING", (0, 0), (-1, -1), 14),
    ]))
    t.hAlign = "CENTER"
    return t


def make_table(headers, rows, col_widths, cell_style_name="TableCell", header_style_name="TableHeader"):
    cs = styles[cell_style_name]
    hs = styles[header_style_name]
    data = [[Paragraph(str(h), hs) for h in headers]]
    for row in rows:
        data.append([Paragraph(str(c), cs) for c in row])
    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), TABLE_HEADER_BG),
        ("TEXTCOLOR", (0, 0), (-1, 0), TABLE_HEADER_FG),
        *[("BACKGROUND", (0, i), (-1, i), TABLE_ALT_ROW) for i in range(2, len(data), 2)],
        ("GRID", (0, 0), (-1, -1), 0.5, TABLE_BORDER),
        ("BOX", (0, 0), (-1, -1), 0.75, TABLE_BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    t.hAlign = "CENTER"
    return t


def add_figure(story, fig_name, caption_text, max_width=460, max_height=380):
    png_path = os.path.join(FIG_DIR, f"{fig_name}.png")
    if not os.path.exists(png_path):
        story.append(Paragraph(f"[Figure {fig_name} not found]", styles["Caption"]))
        return
    from PIL import Image as PILImage
    pil_img = PILImage.open(png_path)
    w, h = pil_img.size
    aspect = h / w
    img_width = min(max_width, w)
    img_height = img_width * aspect
    if img_height > max_height:
        img_height = max_height
        img_width = img_height / aspect
    img = Image(png_path, width=img_width, height=img_height)
    img.hAlign = "CENTER"
    cap = Paragraph(caption_text, styles["Caption"])
    story.append(KeepTogether([img, Spacer(1, 4), cap]))


# ──────────────────────────────────────────────────────────
# Build PDF report
# ──────────────────────────────────────────────────────────
def build_pdf_report():
    print("Building PDF report...")

    output_path = "/mnt/results/report_neurological_countermeasures.pdf"
    doc = SimpleDocTemplate(output_path, pagesize=letter,
                            topMargin=52, bottomMargin=52,
                            leftMargin=60, rightMargin=60)
    story = []

    # Load data
    sig = pd.read_csv(os.path.join(DATA_DIR, "consensus_signature_brain.csv"))
    themes = pd.read_csv(os.path.join(TBL_DIR, "brain_pathway_themes.csv"))
    pk = pd.read_csv(os.path.join(TBL_DIR, "brain_nutrient_pk_table.csv"))
    net = pd.read_csv(os.path.join(TBL_DIR, "brain_gene_pathway_nutrient_network.csv"))
    lincs = pd.read_csv(os.path.join(TBL_DIR, "lincs_brain/tier1_ranking_annotated.csv"))
    recipes = pd.read_csv(os.path.join(TBL_DIR, "vegan_recipes_scored.csv"))
    hallmark = pd.read_csv(os.path.join(TBL_DIR, "gsea_brain_hallmark.csv"))
    reactome = pd.read_csv(os.path.join(TBL_DIR, "gsea_brain_reactome.csv"))

    n_up = (sig["direction"] == "up").sum()
    n_down = (sig["direction"] == "down").sum()
    n_core = sig["core"].sum()
    n_sig_hallmark = (hallmark["p.adjust"] < 0.25).sum()
    n_sig_reactome = (reactome["p.adjust"] < 0.25).sum()

    # ═══════════════════════════════════════════════════════
    # TITLE PAGE
    # ═══════════════════════════════════════════════════════
    story.append(Spacer(1, 50))
    story.append(Paragraph("Neurological Countermeasures for Spaceflight", styles["ReportTitle"]))
    story.append(Paragraph("A Transcriptomic-Driven, Diet-Based Neuroprotection Strategy", styles["Subtitle"]))
    story.append(Spacer(1, 8))
    story.append(Paragraph(
        f"<i>Generated by Biomni  |  {datetime.now().strftime('%B %d, %Y')}</i>",
        styles["Attribution"]))
    story.append(Spacer(1, 30))

    story.append(callout_box(
        "<b>Analysis overview:</b> This report presents a neurological-focused reanalysis of "
        "rodent ISS spaceflight brain transcriptomic data (4 studies, 505 consensus genes), "
        "combined with LINCS L1000 drug connectivity mapping, nutrient pharmacokinetic profiling, "
        "and vegan dietary translation. The goal is to identify how spaceflight damages the brain "
        "at the molecular level and to propose evidence-based nutritional countermeasures that "
        "preserve neurological function during long-duration spaceflight."
    ))
    story.append(Spacer(1, 20))

    # Key findings box
    story.append(Paragraph("Key Findings", styles["SubHead"]))
    findings = [
        f"<b>Brain consensus signature:</b> {len(sig)} genes ({n_up} up, {n_down} down, {n_core} core) from 4 rodent ISS studies",
        f"<b>Dominant pathology:</b> Mitochondrial dysfunction (Complex I, oxidative phosphorylation), protein homeostasis failure, DNA damage repair suppression",
        f"<b>Neuroprotective shift:</b> Upregulation of synaptic signaling, neuronal system, and neurotransmitter pathways suggests compensatory neural remodeling",
        f"<b>Top drug reverser:</b> Vemurafenib (RAF inhibitor, z=-9.68) — but not suitable for prophylactic use",
        f"<b>Top nutrient reversers:</b> Sulforaphane (Nrf2 activator, z=-5.89), Ascorbic acid (z=-5.30), Curcumin (z=-5.30), Luteolin (z=-4.31)",
        f"<b>Best PK profile:</b> Ascorbic acid (active BBB transport, 10x brain concentration) and Sulforaphane (BBB crossing, Nrf2 activation)",
        f"<b>Critical caveat:</b> Curcumin has very low oral bioavailability (unconjugated plasma &lt;2 nM, ~1000x below in vitro effective concentrations)",
    ]
    for f in findings:
        story.append(Paragraph(f"&bull; {f}", styles["BulletItem"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 1: INTRODUCTION
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("1. Introduction: Spaceflight and the Brain", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        "Spaceflight imposes unique stressors on the central nervous system: microgravity, "
        "cosmic radiation, altered circadian rhythms, and confined isolation. These stressors "
        "converge on the brain through several mechanisms: oxidative stress from radiation-induced "
        "reactive oxygen species, mitochondrial dysfunction from impaired energy metabolism, "
        "blood-brain barrier (BBB) disruption from fluid shifts and inflammatory signaling, "
        "and neuroinflammation driven by microglial activation [40, 41, 42].", styles["Body"]))

    story.append(Paragraph(
        "Mao et al. (2020) demonstrated that 35 days aboard the ISS caused a 2.2-fold increase "
        "in hippocampal apoptosis, elevated AQP4 and PECAM-1 expression (indicating BBB "
        "disruption), and reduced ZO-1 (tight junction protein) in mice [44]. Subsequent "
        "proteomic analyses revealed broad mitochondrial changes in the hippocampus, with "
        "TCA cycle enzymes upregulated as a compensatory response to impaired oxidative "
        "phosphorylation [43]. Afshinnekoo et al. (2020) identified mitochondrial dysregulation "
        "as one of six fundamental biological features of spaceflight, and da Silveira et al. "
        "(2020) positioned mitochondrial stress as the central biological hub for spaceflight "
        "impact across tissues [42].", styles["Body"]))

    story.append(Paragraph(
        "This report reanalyzes publicly available rodent ISS brain RNA-seq data from NASA's "
        "Open Science Data Repository (OSDR) to build a consensus spaceflight brain transcriptomic "
        "signature, identifies compounds and nutrients that reverse this signature using LINCS L1000 "
        "connectivity mapping, profiles the pharmacokinetics of candidate neuroprotective nutrients "
        "with specific attention to BBB penetration and brain tissue concentrations, and translates "
        "the findings into a practical vegan dietary countermeasure strategy organized by mission phase.", styles["Body"]))

    story.append(Spacer(1, 10))
    story.append(callout_box(
        "<b>Scope and limitations:</b> This analysis is based on rodent data from 4 ISS missions "
        "(OSD-525, OSD-564, OSD-612, OSD-613). Cross-species translation to human astronauts "
        "requires caution. Pharmacokinetic data are drawn from published literature and may not "
        "account for spaceflight-specific physiological changes (fluid shifts, altered gastric "
        "emptying, radiation effects on drug metabolism). All dietary recommendations should be "
        "validated in human spaceflight analog studies before operational deployment."
    ))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 2: METHODS
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("2. Methods", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph("2.1 Data Sources", styles["SubHead"]))
    story.append(Paragraph(
        "Four rodent ISS spaceflight brain RNA-seq datasets were obtained from NASA OSDR: "
        "OSD-525 (mouse, 35-day ISS mission), OSD-564 (mouse, ISS), OSD-612 (rat, ISS), and "
        "OSD-613 (rat, ISS). All datasets contained spaceflight and ground control samples from "
        "brain tissue (whole brain or specific regions). Raw count matrices were processed "
        "through a standardized pipeline: quality control, normalization (DESeq2 variance-stabilizing "
        "transformation), and gene-level quantification.", styles["Body"]))

    story.append(Paragraph("2.2 Consensus Signature Construction", styles["SubHead"]))
    story.append(Paragraph(
        "A random-effects meta-analysis was performed across the 4 studies using the `metafor` R "
        "package. Pooled log2 fold changes and standard errors were estimated with the restricted "
        "maximum-likelihood (REML) estimator. Genes were classified as consensus differentially "
        "expressed if they met criteria for consistent direction across studies and nominal "
        "significance. Core genes were defined as those significant in all 4 studies. The final "
        "brain consensus signature comprises 505 genes (208 up, 297 down) with 13 core genes.", styles["Body"]))

    story.append(Paragraph("2.3 Pathway Enrichment Analysis", styles["SubHead"]))
    story.append(Paragraph(
        "Gene Set Enrichment Analysis (GSEA) was performed using clusterProfiler against Hallmark "
        "(50 gene sets) and Reactome (2,431 gene sets) pathway databases. Over-representation "
        "analysis (ORA) was performed on up- and downregulated gene sets separately using GO "
        "Biological Process and Reactome annotations. Significance thresholds: GSEA p.adjust &lt; 0.25 "
        "(FDR), ORA p.adjust &lt; 0.05. Pathways were classified into 10 neurological themes using "
        "keyword-based classification of pathway names.", styles["Body"]))

    story.append(Paragraph("2.4 LINCS L1000 Connectivity Mapping", styles["SubHead"]))
    story.append(Paragraph(
        "The brain consensus signature (up/down gene sets) was queried against the LINCS L1000 "
        "perturbational database (~1.8 million profiles) using a weighted connectivity scoring "
        "approach. Compounds with negative connectivity z-scores indicate reversal of the disease "
        "signature. Compounds were annotated with clinical phase, mechanism of action, and target "
        "information from the Broad Drug Repurposing Hub. Nutrient compounds were cross-referenced "
        "with FooDB for vegan food source identification.", styles["Body"]))

    story.append(Paragraph("2.5 Nutrient Pharmacokinetic Profiling", styles["SubHead"]))
    story.append(Paragraph(
        "Pharmacokinetic data for 7 brain-relevant nutrients (sulforaphane, curcumin, luteolin, "
        "EGCG, ascorbic acid, quercetin, resveratrol) were compiled from published literature "
        "identified through systematic searches. Data fields include: BBB penetration, oral "
        "bioavailability, peak plasma concentration, time to peak, half-life, brain tissue "
        "concentration, human dose, and spaceflight relevance. Each nutrient was scored on a "
        "0-5 scale across 6 axes for comparative profiling.", styles["Body"]))

    story.append(Paragraph("2.6 Dietary Translation", styles["SubHead"]))
    story.append(Paragraph(
        "Nutrient candidates with vegan food sources were mapped to specific foods using FooDB. "
        "Twelve curated vegan recipes were designed to maximize coverage of the 10 countermeasure "
        "nutrients (sulforaphane, curcumin, ascorbic acid, quercetin, luteolin, resveratrol, EGCG, "
        "gingerol, allicin, lutein) and assigned to mission phases (pre-flight, in-flight, "
        "post-flight) based on their pharmacological rationale.", styles["Body"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 3: RESULTS — BRAIN SIGNATURE
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("3. Results: Spaceflight Brain Transcriptomic Signature", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph("3.1 Consensus Gene Signature", styles["SubHead"]))
    story.append(Paragraph(
        f"The random-effects meta-analysis across 4 rodent ISS brain studies yielded a consensus "
        f"signature of {len(sig)} differentially expressed genes: {n_up} upregulated and {n_down} "
        f"downregulated, with {n_core} core genes consistently altered across all studies. The "
        f"skew toward downregulation (59% down vs. 41% up) reflects the dominant suppressive "
        f"effect of spaceflight on brain metabolic and biosynthetic processes.", styles["Body"]))

    add_figure(story, "fig1_brain_volcano",
        "<b>Figure 1.</b> Brain transcriptomic response to spaceflight. Volcano plot of pooled "
        "log2 fold change vs. -log10(adjusted p-value) from the random-effects meta-analysis of "
        "4 rodent ISS brain studies. Orange: consensus upregulated; blue: consensus downregulated; "
        "gold: core genes. Dashed line: adjusted p = 0.05.")

    story.append(Paragraph("3.2 Pathway Enrichment by Neurological Theme", styles["SubHead"]))
    story.append(Paragraph(
        f"GSEA identified {n_sig_hallmark} significant Hallmark pathways and {n_sig_reactome} "
        f"significant Reactome pathways (p.adjust &lt; 0.25). Classification into 10 neurological "
        f"themes revealed a clear dichotomy: energy-intensive biosynthetic and maintenance "
        f"processes were suppressed, while neuronal signaling and structural adaptation pathways "
        f"were activated.", styles["Body"]))

    # Theme summary table
    theme_summary = themes.groupby("theme").agg(
        n_pathways=("pathway", "count"),
        mean_NES=("NES", "mean"),
        n_down=("direction", lambda x: (x == "downregulated").sum()),
        n_up=("direction", lambda x: (x == "upregulated").sum()),
    ).reset_index().sort_values("mean_NES")

    theme_rows = []
    for _, r in theme_summary.iterrows():
        direction = "Down" if r["mean_NES"] < 0 else "Up"
        theme_rows.append([
            r["theme"],
            str(int(r["n_pathways"])),
            f'{r["mean_NES"]:+.2f}',
            direction,
        ])

    story.append(make_table(
        ["Neurological Theme", "Pathways", "Mean NES", "Direction"],
        theme_rows,
        [180, 70, 80, 80]
    ))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "<b>Table 1.</b> Brain GSEA pathways classified by neurological theme. "
        "Mean NES &lt; 0 indicates net downregulation; &gt; 0 indicates net upregulation.",
        styles["Caption"]))

    add_figure(story, "fig2_gsea_theme_dotplot",
        "<b>Figure 2.</b> Brain GSEA pathways grouped by neurological theme. Top 3 pathways per "
        "theme shown by |NES|. Orange bars: upregulated; blue bars: downregulated. Dot size "
        "proportional to -log10(adjusted p-value).")

    story.append(Paragraph("3.3 Key Pathway Findings", styles["SubHead"]))

    story.append(Paragraph(
        "<b>Mitochondrial dysfunction (downregulated, mean NES=-1.57):</b> The most prominent "
        "feature of the brain signature. Top pathways include respiratory electron transport "
        "(NES=-2.56), Complex I biogenesis (NES=-2.54), and mitochondrial translation elongation "
        "(NES=-2.63). Hallmark oxidative phosphorylation was strongly suppressed (NES=-2.13). "
        "This is consistent with the mitochondrial stress hub identified by da Silveira et al. "
        "(2020) as central to spaceflight biology [42].", styles["Body"]))

    story.append(Paragraph(
        "<b>Protein homeostasis (downregulated, mean NES=-1.57):</b> The unfolded protein response "
        "(NES=-1.65) and protein folding/processing pathways were suppressed, suggesting impaired "
        "ER stress capacity. This may compromise the brain's ability to manage misfolded proteins "
        "under spaceflight stress.", styles["Body"]))

    story.append(Paragraph(
        "<b>DNA damage repair (downregulated, mean NES=-1.38):</b> Hallmark DNA repair (NES=-1.85) "
        "and multiple repair pathways (base excision, nucleotide excision, double-strand break "
        "repair) were suppressed. Combined with elevated radiation exposure, this creates a "
        "vulnerability to accumulated DNA damage in the brain.", styles["Body"]))

    story.append(Paragraph(
        "<b>Synaptic and neuronal signaling (upregulated, mean NES=+1.53):</b> Neuronal system "
        "(NES=+1.85), transmission across chemical synapses (NES=+1.80), NMDA receptor activation "
        "(NES=+1.89), and long-term potentiation (NES=+1.66) were all upregulated. This may "
        "represent compensatory neural remodeling or a response to altered sensory input in "
        "microgravity, but sustained upregulation could indicate excitotoxic risk.", styles["Body"]))

    story.append(Paragraph(
        "<b>Circadian and cholesterol dysregulation (upregulated, mean NES=+1.73):</b> Bile acid "
        "metabolism (NES=+1.56) and cholesterol biosynthesis regulation were upregulated, "
        "consistent with altered circadian rhythm and metabolic adaptation in spaceflight.", styles["Body"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 4: SPACEFLIGHT BRAIN INJURY MECHANISM
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("4. Spaceflight Brain Injury Mechanism", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        "Integrating the transcriptomic findings with published spaceflight neuroscience "
        "literature, we propose a four-tier mechanism cascade (Figure 5) linking spaceflight "
        "stressors to neurological outcomes:", styles["Body"]))

    story.append(Paragraph(
        "<b>Tier 1 - Spaceflight stressors:</b> Microgravity alters fluid distribution and "
        "mechanical loading on brain tissue. Cosmic radiation (particularly high-LET particles) "
        "generates reactive oxygen species and causes direct DNA damage. Circadian disruption "
        "from 90-minute day-night cycles on the ISS dysregulates clock-controlled genes [40, 41].", styles["Body"]))

    story.append(Paragraph(
        "<b>Tier 2 - Cellular stress response:</b> The convergence of these stressors produces "
        "oxidative stress (elevated ROS), DNA damage (double-strand breaks), and mitochondrial "
        "dysfunction (Complex I deficit). Our transcriptomic data show that the brain's antioxidant "
        "defense genes are insufficiently upregulated, and mitochondrial energy production pathways "
        "are actively suppressed [42, 43, 44].", styles["Body"]))

    story.append(Paragraph(
        "<b>Tier 3 - Molecular consequences:</b> BBB disruption is evidenced by ZO-1 downregulation "
        "and AQP4/PECAM-1 upregulation in spaceflight brain tissue [44]. Protein homeostasis "
        "failure (UPR suppression) impairs clearance of damaged proteins. Neuroinflammation "
        "is triggered by NF-kB activation and cytokine release. Synaptic signaling alterations "
        "may reflect compensatory remodeling or excitotoxic stress.", styles["Body"]))

    story.append(Paragraph(
        "<b>Tier 4 - Neurological outcomes:</b> The culmination of these molecular changes is "
        "hippocampal apoptosis (2.2-fold increase in 35-day ISS mission [44]), cognitive decline "
        "(observed in astronaut neurocognitive testing), and sensorimotor impairment (balance "
        "and coordination deficits upon return to gravity).", styles["Body"]))

    add_figure(story, "fig5_spaceflight_brain_mechanism",
        "<b>Figure 5.</b> Spaceflight brain injury mechanism cascade. Four-tier model linking "
        "spaceflight stressors (microgravity, radiation, circadian disruption) through cellular "
        "stress responses and molecular consequences to neurological outcomes. Molecular markers "
        "derived from spaceflight rodent brain transcriptomics and proteomics.",
        max_width=380, max_height=500)

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 5: LINCS DRUG & NUTRIENT REVERSERS
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("5. LINCS L1000 Drug and Nutrient Reversers", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        f"The brain consensus signature was screened against the LINCS L1000 perturbational "
        f"database, yielding {len(lincs)} candidate reverser compounds. The top 15 reversers "
        f"by median connectivity z-sum are shown in Figure 3 and Table 2.", styles["Body"]))

    add_figure(story, "fig3_lincs_reversers_bar",
        "<b>Figure 3.</b> Top 15 brain LINCS L1000 reversers. Bar color indicates clinical phase. "
        "More negative z-sum indicates stronger reversal of the spaceflight brain signature.")

    # LINCS top 15 table
    top15 = lincs.head(15)
    lincs_rows = []
    for _, r in top15.iterrows():
        compound = str(r["compound"]).replace("_", " ").title()
        phase = str(r["drh_clinical_phase"]) if pd.notna(r["drh_clinical_phase"]) else "Unknown"
        moa = str(r["drh_moa"])[:30] if pd.notna(r["drh_moa"]) else "-"
        lincs_rows.append([
            str(int(r["rank"])),
            compound,
            f'{r["median_z_sum"]:.2f}',
            phase,
            moa,
        ])

    story.append(make_table(
        ["Rank", "Compound", "Z-sum", "Phase", "Mechanism"],
        lincs_rows,
        [35, 110, 55, 65, 145],
        cell_style_name="TableCellSmall"
    ))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "<b>Table 2.</b> Top 15 brain LINCS L1000 reversers by median connectivity z-sum.",
        styles["Caption"]))

    story.append(Paragraph("5.1 Drug Reversers", styles["SubHead"]))
    story.append(Paragraph(
        "Vemurafenib (RAF inhibitor, z=-9.68) is the strongest reverser but is an oncology drug "
        "unsuitable for prophylactic use. Chlorambucil (DNA alkylator) and formoterol (beta-2 "
        "adrenergic agonist) are also potent but carry significant side-effect concerns. "
        "Bicalutamide (androgen receptor antagonist, z=-6.52) and sangivamycin (DNA inhibitor, "
        "Phase 1) round out the top pharmacological candidates. These drugs confirm that the "
        "brain signature is pharmacologically reversible but are not practical countermeasures "
        "for healthy astronauts.", styles["Body"]))

    story.append(Paragraph("5.2 Nutrient Reversers", styles["SubHead"]))
    story.append(Paragraph(
        "Four nutrients appear in the brain LINCS ranking: sulforaphane (rank 7, z=-5.89, "
        "Phase 2, Nrf2 activator), ascorbic acid (rank 10, z=-5.30), curcumin (z=-5.30), and "
        "luteolin (rank 19, z=-4.31, Phase 2). These nutrients reverse the brain signature "
        "through mechanisms that directly target the identified pathological pathways: Nrf2/ARE "
        "activation for oxidative stress, NF-kB inhibition for neuroinflammation, and antioxidant "
        "activity for ROS scavenging. Three additional nutrients (EGCG, quercetin, resveratrol) "
        "were included based on mechanistic relevance to the brain signature pathways, even "
        "though they were identified through the liver screening stratum.", styles["Body"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 6: NUTRIENT PHARMACOKINETICS
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("6. Nutrient Pharmacokinetic Profiling", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        "For each of the 7 candidate neuroprotective nutrients, we compiled pharmacokinetic data "
        "from published literature with specific attention to BBB penetration, brain tissue "
        "concentration, and spaceflight relevance. The comparative profile is shown in Figure 4 "
        "and detailed in Table 3.", styles["Body"]))

    add_figure(story, "fig4_nutrient_pk_radar",
        "<b>Figure 4.</b> Nutrient pharmacokinetic profile comparison. Seven nutrients scored "
        "on 6 axes (0-5 scale): BBB penetration, oral bioavailability, brain concentration, "
        "evidence grade, LINCS reversal strength, and spaceflight relevance.")

    # PK summary table (key fields)
    pk_rows = []
    for _, r in pk.iterrows():
        pk_rows.append([
            r["nutrient"],
            r["bbb_penetration"][:45] + "..." if len(r["bbb_penetration"]) > 45 else r["bbb_penetration"],
            r["oral_bioavailability"][:35] + "..." if len(r["oral_bioavailability"]) > 35 else r["oral_bioavailability"],
            r["brain_concentration"][:40] + "..." if len(r["brain_concentration"]) > 40 else r["brain_concentration"],
            r["evidence_grade"][:25] + "..." if len(r["evidence_grade"]) > 25 else r["evidence_grade"],
        ])

    story.append(make_table(
        ["Nutrient", "BBB Penetration", "Oral Bioavail.", "Brain Conc.", "Evidence"],
        pk_rows,
        [85, 110, 90, 100, 85],
        cell_style_name="TableCellSmall"
    ))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "<b>Table 3.</b> Pharmacokinetic summary for 7 brain-relevant nutrients. Full PK data "
        "(16 columns including peak plasma, t-peak, half-life, human dose, spaceflight relevance, "
        "and citations) in Supplementary Table.", styles["Caption"]))

    # Individual nutrient profiles
    story.append(Paragraph("6.1 Sulforaphane", styles["SubHead"]))
    story.append(Paragraph(
        "Sulforaphane, an isothiocyanate from cruciferous vegetables, is the strongest nutrient "
        "candidate. It crosses the BBB and accumulates in the ventral midbrain and striatum within "
        "15 minutes of administration, with brain levels diminishing after ~2 hours [5, 6]. "
        "Oral bioavailability is high (~80% as glucoraphanin with myrosinase). In humans, peak "
        "plasma reaches ~1 uM after a 200 umol dose; in rats, ~20 uM after 50 umol [6]. "
        "Sulforaphane activates the Nrf2/ARE pathway, inducing Phase II detox enzymes (HO-1, "
        "NQO1, GST) that directly counteract the oxidative stress and mitochondrial dysfunction "
        "central to the brain signature. It also preconditioning-protects the BBB against "
        "disruption [2]. Clinical trials for neurological conditions are ongoing.", styles["Body"]))

    story.append(Paragraph("6.2 Ascorbic Acid (Vitamin C)", styles["SubHead"]))
    story.append(Paragraph(
        "Vitamin C has the best-documented brain pharmacokinetic profile among all nutrients. "
        "It is actively transported across the BBB and blood-CSF barrier via the SVCT2 transporter, "
        "maintaining brain concentrations approximately 10-fold higher than plasma [37, 39]. "
        "Normal plasma levels (~50 uM) yield CSF concentrations of ~200 uM, with even higher "
        "intracellular brain concentrations (~10 mM) [37]. CSF levels drop only when plasma falls "
        "below ~28.4 umol/L [39]. Oral bioavailability is high (70-90% at moderate doses, saturable "
        "above ~500 mg/day). Vitamin C directly scavenges ROS, supports BBB structural integrity "
        "(collagen synthesis), and is essential for neurotransmitter synthesis (dopamine "
        "beta-hydroxylase conversion of dopamine to norepinephrine) [36]. Plasma levels may "
        "decline during spaceflight due to stress and altered nutrition, making supplementation "
        "particularly important.", styles["Body"]))

    story.append(Paragraph("6.3 Curcumin — Critical Bioavailability Limitation", styles["SubHead"]))
    story.append(callout_box(
        "<b>Critical caveat:</b> A 2025 critical reappraisal by Kroon et al. (iScience) "
        "demonstrated that unconjugated curcumin plasma levels remain ~1000-fold below in vitro "
        "effective concentrations (1-100 uM) across all tested formulations. Even NovaSOL, the "
        "best-performing formulation, achieved a median Cmax of only 14.9 nM (range 6.7-38.4 nM) "
        "at 1 hour, declining to 1.2 nM at 4 hours [12]. Piperine does NOT improve curcumin "
        "bioavailability as commonly claimed. Most circulating curcumin exists as glucuronide and "
        "sulfate conjugates, which are not membrane-permeable and cannot cross the BBB [13, 14]. "
        "Dietary curcumin alone is unlikely to achieve therapeutic brain concentrations."
    ))
    story.append(Spacer(1, 8))
    story.append(Paragraph(
        "Despite these PK limitations, curcumin remains mechanistically relevant: it inhibits "
        "NF-kB, activates Nrf2, and has anti-amyloid aggregation properties. Nanoformulation or "
        "intravenous delivery may be needed for meaningful CNS effects. Curcumin is retained in "
        "the dietary strategy as a complementary anti-inflammatory agent, but with the explicit "
        "caveat that it should not be relied upon as a primary countermeasure.", styles["Body"]))

    story.append(Paragraph("6.4 Luteolin", styles["SubHead"]))
    story.append(Paragraph(
        "Luteolin, a flavone found in celery, parsley, and olive, shows medium BBB permeability "
        "[20] and multi-target neuroprotection via Nrf2, NF-kB, MAPK, and JAK-STAT pathways "
        "[19]. In an in vitro BBB model, luteolin preserved barrier function and reduced "
        "COX-2, TNF-alpha, IL-1beta, IL-6, and IL-8 via p38 MAPK-NF-kB suppression [22]. "
        "Oral bioavailability is low-moderate (~30%), improved by glycoside forms. Human clinical "
        "evidence for neuroprotection is limited but mechanistic data are strong.", styles["Body"]))

    story.append(Paragraph("6.5 EGCG (Epigallocatechin gallate)", styles["SubHead"]))
    story.append(Paragraph(
        "EGCG from green tea crosses the BBB, with both EGCG and its microbial metabolites "
        "(valerolactones) reaching brain tissue and promoting neuritogenesis [33]. It activates "
        "AMPK and Nrf2/ARE pathways, promotes autophagy (including mitophagy for clearing damaged "
        "mitochondria), and modulates mTOR signaling [29, 31]. Oral bioavailability is low "
        "(~10-20%) due to rapid metabolism, but can be enhanced by fasting and liposomal "
        "formulations [32]. Clinical trials for neuroprotection are ongoing.", styles["Body"]))

    story.append(Paragraph("6.6 Quercetin", styles["SubHead"]))
    story.append(Paragraph(
        "Quercetin, a flavonol from onions, apples, and capers, crosses the BBB and preserves "
        "BBB integrity after injury [26, 27]. At 50 mg/kg in vivo, it reduced TBI-induced vascular "
        "hyperpermeability [26]. It activates SIRT1 and NF-kB inhibition pathways, preserves "
        "mitochondrial membrane potential, and has senolytic activity (clearing stress-induced "
        "senescent cells) [24, 25]. Oral bioavailability is low (~2-5% for aglycone) but improved "
        "by glycoside forms and lipid co-administration.", styles["Body"]))

    story.append(Paragraph("6.7 Resveratrol", styles["SubHead"]))
    story.append(Paragraph(
        "Resveratrol, a stilbene from grape skin, crosses the BBB and activates SIRT1, promoting "
        "mitochondrial biogenesis via PGC-1alpha and TFAM [48, 49]. This directly counteracts the "
        "suppressed mitochondrial biogenesis in the brain signature. It also activates AMPK and "
        "Nrf2 pathways [45]. However, oral bioavailability is very low (~1%) due to rapid phase II "
        "metabolism (glucuronidation, sulfation). Unconjugated plasma levels reach only ~20-200 nM "
        "after high-dose supplementation. Micronized or nanoformulated preparations are preferred "
        "for therapeutic use.", styles["Body"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 7: INTERVENTION NETWORK
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("7. Nutrient-Pathway-Gene Intervention Network", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        "The 7 nutrients were mapped to the brain signature pathways they target and the "
        "downstream protective mechanisms they activate, creating a tripartite intervention "
        "network (Figure 6). The network comprises 27 nutrient-pathway edges connecting 7 "
        "nutrients to 10 target pathways, with gene-level overlap confirmed through GSEA core "
        "enrichment analysis.", styles["Body"]))

    add_figure(story, "fig6_nutrient_intervention_network",
        "<b>Figure 6.</b> Nutrient-pathway-gene intervention network. Left: 7 neuroprotective "
        "nutrients. Center: 5 spaceflight-damaged brain pathways. Right: 4 downstream protective "
        "mechanisms. Solid lines: activation; dashed lines: inhibition.",
        max_width=460, max_height=340)

    story.append(Paragraph(
        "The network reveals complementary coverage: sulforaphane and EGCG both activate Nrf2/ARE "
        "to counteract oxidative phosphorylation suppression; resveratrol and EGCG promote "
        "mitochondrial biogenesis via SIRT1/PGC-1alpha; quercetin uniquely preserves BBB integrity "
        "(ZO-1); ascorbic acid supports both neurotransmitter synthesis and BBB structural "
        "integrity; luteolin and curcumin inhibit NF-kB-driven neuroinflammation. No single "
        "nutrient covers all pathological pathways, supporting a multi-nutrient combination "
        "strategy.", styles["Body"]))

    # Network table
    net_rows = []
    for _, r in net.iterrows():
        net_rows.append([
            r["nutrient"],
            r["target_pathway"].replace("HALLMARK_", "").replace("REACTOME_", "").replace("_", " ")[:40],
            f'{r["pathway_NES"]:+.2f}',
            str(int(r["n_signature_overlap"])),
        ])

    story.append(make_table(
        ["Nutrient", "Target Pathway", "Pathway NES", "Gene Overlap"],
        net_rows,
        [90, 200, 80, 80],
        cell_style_name="TableCellSmall"
    ))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "<b>Table 4.</b> Nutrient-pathway intervention network edges. Gene overlap = number of "
        "brain consensus signature genes in the GSEA core enrichment of the target pathway.",
        styles["Caption"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 8: DIETARY COUNTERMEASURES
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("8. Dietary Countermeasure Strategy", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        "The 7 neuroprotective nutrients, plus 3 additional countermeasure compounds (gingerol, "
        "allicin, lutein), were translated into 12 curated vegan recipes organized by mission "
        "phase (Figure 7, Table 5). The strategy follows a phased approach: preconditioning "
        "(pre-flight), continuous protection (in-flight), and recovery (post-flight).", styles["Body"]))

    add_figure(story, "fig7_diet_mission_phase",
        "<b>Figure 7.</b> Diet-neuroprotection strategy by mission phase. Pre-flight "
        "(preconditioning), in-flight (continuous protection), and post-flight (recovery) "
        "dietary interventions with specific nutrient targets.",
        max_width=460, max_height=340)

    # Recipe table
    recipe_rows = []
    for _, r in recipes.iterrows():
        name = r["name"][:30] + "..." if len(r["name"]) > 30 else r["name"]
        recipe_rows.append([
            name,
            r["meal_type"],
            r["phase"].replace("_", " ").title(),
            str(r["nutrient_score"]),
            str(r["target_nutrients"])[:50] + "..." if len(str(r["target_nutrients"])) > 50 else str(r["target_nutrients"]),
        ])

    story.append(make_table(
        ["Recipe", "Meal", "Phase", "Score", "Key Nutrients"],
        recipe_rows,
        [110, 60, 65, 45, 170],
        cell_style_name="TableCellSmall"
    ))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "<b>Table 5.</b> Curated vegan recipes for neurological countermeasures. Score reflects "
        "total countermeasure nutrient coverage.", styles["Caption"]))

    add_figure(story, "fig8_recipe_nutrient_heatmap",
        "<b>Figure 8.</b> Vegan recipe nutrient coverage heatmap. Gold cells indicate nutrient "
        "presence. Left margin: mission phase color coding. Right margin: total nutrient score.")

    story.append(Paragraph("8.1 Pre-flight Preconditioning (T-30 days)", styles["SubHead"]))
    story.append(Paragraph(
        "The goal is to optimize brain antioxidant status and BBB integrity before launch. "
        "Key interventions: broccoli sprouts for sulforaphane loading (Nrf2 pathway priming), "
        "citrus fruits for vitamin C saturation (plasma &gt;50 uM), green tea for EGCG-mediated "
        "mitochondrial priming, and quercetin-rich foods (onions, apples, capers) for BBB "
        "strengthening. The Kale Caesar with Capers and Roasted Root Vegetables recipes are "
        "optimized for this phase.", styles["Body"]))

    story.append(Paragraph("8.2 In-flight Continuous Protection", styles["SubHead"]))
    story.append(Paragraph(
        "During ISS deployment, the goal is to counteract ongoing oxidative stress, mitochondrial "
        "dysfunction, and neuroinflammation. Key interventions: daily broccoli/kale for sustained "
        "sulforaphane, turmeric curry for curcumin (with bioavailability caveat), green tea "
        "smoothies for EGCG + ascorbic acid, quercetin foods for BBB maintenance under microgravity, "
        "and luteolin-rich herbs (celery, sage, oregano) for neuroinflammation control. The "
        "Broccoli Sulforaphane Power Bowl (score=143) and Spiced Chickpea and Spinach Curry "
        "(score=137) provide the broadest nutrient coverage.", styles["Body"]))

    story.append(Paragraph("8.3 Post-flight Recovery (T+30 days)", styles["SubHead"]))
    story.append(Paragraph(
        "After return to gravity, the goal is to repair BBB damage, clear damaged mitochondria "
        "(mitophagy), and restore cognitive function. Key interventions: cruciferous salad for "
        "sulforaphane-mediated BBB repair, ginger-green tea broth for EGCG + gingerol recovery "
        "support, berry-rich breakfast for quercetin + ascorbic acid antioxidant restoration, "
        "and cocoa-chia pudding for quercetin-mediated senescent cell clearance.", styles["Body"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 9: DISCUSSION
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("9. Discussion", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        "This analysis reveals that spaceflight induces a coherent brain transcriptomic signature "
        "characterized by mitochondrial energy failure, impaired protein homeostasis, and "
        "suppressed DNA repair, alongside compensatory upregulation of neuronal signaling pathways. "
        "These findings are consistent with the mitochondrial stress hub model of spaceflight "
        "biology [42] and with direct measurements of hippocampal apoptosis and BBB disruption "
        "in ISS-flown rodents [44].", styles["Body"]))

    story.append(Paragraph(
        "The LINCS L1000 screening confirms that this signature is pharmacologically reversible. "
        "While the top drug reversers (vemurafenib, chlorambucil) are unsuitable for prophylactic "
        "use, the identification of sulforaphane, ascorbic acid, curcumin, and luteolin as "
        "nutrient reversers provides a practical, low-risk intervention strategy. The nutrient "
        "selection is further supported by mechanistic overlap with the brain signature pathways: "
        "Nrf2/ARE activation (sulforaphane, EGCG, luteolin) directly addresses oxidative "
        "phosphorylation suppression; SIRT1/PGC-1alpha activation (resveratrol, EGCG, quercetin) "
        "promotes mitochondrial biogenesis; and BBB integrity preservation (quercetin, ascorbic "
        "acid) addresses the vascular disruption identified by Mao et al. [44].", styles["Body"]))

    story.append(Paragraph(
        "The pharmacokinetic analysis introduces important nuance. Ascorbic acid and sulforaphane "
        "stand out as the most pharmacologically viable nutrients: both cross the BBB efficiently, "
        "achieve therapeutic brain concentrations, and have strong human safety data. Curcumin, "
        "despite its mechanistic appeal and LINCS reversal score, has a critical bioavailability "
        "limitation — the 2025 critical reappraisal by Kroon et al. [12] shows that unconjugated "
        "curcumin plasma levels remain ~1000-fold below in vitro effective concentrations. "
        "This does not invalidate curcumin's inclusion in the dietary strategy, but it does "
        "require honest framing: curcumin should be considered a complementary anti-inflammatory "
        "agent rather than a primary countermeasure, and nanoformulation research should be "
        "prioritized for spaceflight applications.", styles["Body"]))

    story.append(Paragraph(
        "The upregulation of synaptic signaling pathways (neuronal system, NMDA receptor "
        "activation, long-term potentiation) is a notable finding that warrants careful "
        "interpretation. While this may represent beneficial neural plasticity and adaptation "
        "to the spaceflight environment, sustained upregulation of excitatory signaling could "
        "predispose to excitotoxicity, particularly if mitochondrial energy production is "
        "compromised (as our data show). The inclusion of neuroprotective nutrients that support "
        "mitochondrial function (resveratrol, EGCG) while modulating excitatory signaling "
        "(luteolin's MAO inhibition) may help balance this risk.", styles["Body"]))

    story.append(Paragraph(
        "Several limitations should be acknowledged. First, the analysis is based on rodent data, "
        "and cross-species translation to human astronauts requires validation. Second, "
        "pharmacokinetic data are from Earth-based studies; spaceflight physiology (fluid shifts, "
        "altered gastric emptying, radiation effects on drug metabolism) may alter nutrient "
        "absorption and distribution. Third, the LINCS L1000 database profiles cell line responses "
        "to perturbagens, which may not fully recapitulate in vivo brain pharmacology. Fourth, "
        "the dietary recommendations are based on nutrient content and mechanistic reasoning, "
        "not on interventional trials in spaceflight analogs. Finally, the pathway theme "
        "classification uses keyword-based rules, which may misclassify some pathways.", styles["Body"]))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════
    # SECTION 10: CONCLUSIONS
    # ═══════════════════════════════════════════════════════
    story.append(Paragraph("10. Conclusions and Recommendations", styles["SectionHead"]))
    story.append(divider())

    story.append(Paragraph(
        "Spaceflight induces a brain transcriptomic signature dominated by mitochondrial "
        "dysfunction, protein homeostasis failure, and DNA repair suppression, with compensatory "
        "neuronal signaling upregulation. Seven vegan nutrients — sulforaphane, ascorbic acid, "
        "quercetin, EGCG, luteolin, curcumin, and resveratrol — target these pathological "
        "pathways through complementary mechanisms. Based on pharmacokinetic evidence, ascorbic "
        "acid and sulforaphane are the highest-priority countermeasures, followed by quercetin "
        "and EGCG. Curcumin is included with a bioavailability caveat.", styles["Body"]))

    story.append(Paragraph("Priority Recommendations:", styles["SubHead"]))
    recommendations = [
        "<b>Tier 1 (highest priority):</b> Ascorbic acid (200-500 mg/day) and sulforaphane (broccoli sprouts, ~100 umol/day) — both have confirmed BBB penetration, therapeutic brain concentrations, and directly target the dominant pathological pathways",
        "<b>Tier 2 (high priority):</b> Quercetin (onion/apple sources, 100-500 mg/day) for BBB integrity preservation, and EGCG (green tea, 200-400 mg/day) for mitochondrial support and mitophagy",
        "<b>Tier 3 (moderate priority):</b> Luteolin (herbs, 50-100 mg/day) for neuroinflammation control, and resveratrol (grape/peanut sources, 150-500 mg/day) for mitochondrial biogenesis (bioavailability-enhanced formulations preferred)",
        "<b>Tier 4 (complementary):</b> Curcumin (turmeric, 2-4 g/day) as a complementary anti-inflammatory agent with explicit bioavailability limitations; nanoformulation recommended for therapeutic CNS effects",
        "<b>Research priorities:</b> Validate nutrient PK in spaceflight analogs (head-down tilt bed rest, radiation exposure); test multi-nutrient combinations in rodent spaceflight models; develop nanoformulated curcumin and resveratrol for enhanced BBB delivery",
    ]
    for rec in recommendations:
        story.append(Paragraph(f"&bull; {rec}", styles["BulletItem"]))

    story.append(Spacer(1, 20))
    story.append(divider())
    story.append(Paragraph(
        "<i>This report was generated by Biomni (Phylo) using NASA OSDR rodent ISS brain "
        "transcriptomic data, LINCS L1000 connectivity mapping, and published pharmacokinetic "
        "literature. All analyses are reproducible from the provided scripts and data files.</i>",
        styles["Caption"]))

    # Build PDF
    doc.build(story, onFirstPage=page_header_footer, onLaterPages=page_header_footer)
    print(f"  PDF saved: {output_path}")

    # Validate
    from pypdf import PdfReader
    reader = PdfReader(output_path)
    page_count = len(reader.pages)
    file_size = os.path.getsize(output_path)
    first_page_text = reader.pages[0].extract_text()
    print(f"  Validation: {page_count} pages, {file_size/1024:.0f} KB, "
          f"first page text length: {len(first_page_text.strip())} chars")
    assert page_count >= 10, f"Report too short: {page_count} pages"
    assert file_size > 50000, f"Report too small: {file_size} bytes"
    assert len(first_page_text.strip()) > 0, "First page has no text"

    return output_path


# ──────────────────────────────────────────────────────────
# LaTeX manuscript
# ──────────────────────────────────────────────────────────
def build_latex_manuscript():
    print("\nBuilding LaTeX manuscript...")
    output_path = "/mnt/results/manuscript_neurological_countermeasures.tex"

    sig = pd.read_csv(os.path.join(DATA_DIR, "consensus_signature_brain.csv"))
    n_up = (sig["direction"] == "up").sum()
    n_down = (sig["direction"] == "down").sum()
    n_core = sig["core"].sum()

    latex = r"""\documentclass[11pt,a4paper]{article}
\usepackage[utf8]{inputenc}
\usepackage[margin=1in]{geometry}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{longtable}
\usepackage{hyperref}
\usepackage{natbib}
\usepackage{amsmath}
\usepackage{xcolor}

\title{Neurological Countermeasures for Spaceflight: A Transcriptomic-Driven, \\
       Diet-Based Neuroprotection Strategy}
\author{Richard Barker \\ \small Collaborative Science Environment Inc.}
\date{\today}

\begin{document}
\maketitle

\begin{abstract}
Spaceflight imposes unique stressors on the central nervous system, including microgravity, cosmic radiation, and circadian disruption. We analyzed rodent ISS brain RNA-seq data from 4 NASA OSDR studies (OSD-525, OSD-564, OSD-612, OSD-613) using random-effects meta-analysis to construct a consensus brain transcriptomic signature of \textbf{""" + str(len(sig)) + r""" genes} (""" + str(n_up) + r""" up, """ + str(n_down) + r""" down, """ + str(n_core) + r""" core). GSEA revealed dominant downregulation of mitochondrial oxidative phosphorylation (NES=-2.13), Complex I biogenesis (NES=-2.54), and protein homeostasis pathways, alongside upregulation of neuronal signaling (NES=+1.85), NMDA receptor activation (NES=+1.89), and long-term potentiation (NES=+1.66). LINCS L1000 connectivity mapping identified 221 candidate reverser compounds, including the nutrients sulforaphane (z=-5.89), ascorbic acid (z=-5.30), curcumin (z=-5.30), and luteolin (z=-4.31). Pharmacokinetic profiling of 7 brain-relevant nutrients identified ascorbic acid and sulforaphane as highest-priority countermeasures based on BBB penetration, brain tissue concentration, and spaceflight pathway relevance. We propose a phased vegan dietary countermeasure strategy (pre-flight preconditioning, in-flight protection, post-flight recovery) targeting mitochondrial dysfunction, oxidative stress, BBB disruption, and neuroinflammation. A critical finding is that curcumin, despite strong mechanistic evidence, has oral bioavailability ~1000-fold below therapeutic concentrations, requiring nanoformulation for CNS efficacy.
\end{abstract}

\section{Introduction}
Spaceflight induces neurological changes including hippocampal apoptosis, blood-brain barrier (BBB) disruption, and cognitive impairment \citep{Mao2020,Afshinnekoo2020}. Mitochondrial dysfunction has been identified as a central biological hub of spaceflight impact \citep{daSilveira2020}. We reanalyze rodent ISS brain transcriptomic data to characterize the neurological signature of spaceflight and identify evidence-based nutritional countermeasures.

\section{Methods}
\subsection{Data and Meta-Analysis}
Four rodent ISS brain RNA-seq datasets (OSD-525, OSD-564, OSD-612, OSD-613) were obtained from NASA OSDR. Random-effects meta-analysis was performed using \texttt{metafor} (REML estimator). Consensus genes required consistent direction across studies; core genes were significant in all 4 studies.

\subsection{Pathway Enrichment}
GSEA was performed with clusterProfiler against Hallmark and Reactome databases (p.adj $<$ 0.25). Pathways were classified into 10 neurological themes using keyword-based rules.

\subsection{LINCS L1000 Screening}
The consensus signature was queried against LINCS L1000 ($\sim$1.8M profiles). Negative connectivity z-scores indicate signature reversal. Compounds were annotated with Broad Drug Repurposing Hub data.

\subsection{Nutrient Pharmacokinetics}
PK data for 7 nutrients were compiled from published literature, including BBB penetration, oral bioavailability, peak plasma, brain concentration, and human dose.

\section{Results}
\subsection{Brain Consensus Signature}
The meta-analysis yielded """ + str(len(sig)) + r""" consensus genes (""" + str(n_up) + r""" up, """ + str(n_down) + r""" down) with """ + str(n_core) + r""" core genes. The signature is skewed toward downregulation, reflecting suppression of metabolic and biosynthetic processes (Figure 1).

\subsection{Pathway Enrichment}
GSEA identified 23 significant Hallmark and 527 significant Reactome pathways. The dominant downregulated themes were mitochondrial dysfunction (mean NES=-1.57), protein homeostasis (mean NES=-1.57), and DNA damage repair (mean NES=-1.38). Upregulated themes included synaptic/neuronal signaling (mean NES=+1.53) and circadian/cholesterol dysregulation (mean NES=+1.73) (Figure 2, Table 1).

\subsection{LINCS Reversers}
LINCS screening identified 221 candidate reversers. Top drug reversers included vemurafenib (z=-9.68, RAF inhibitor) and chlorambucil (z=-7.24, DNA inhibitor). Nutrient reversers included sulforaphane (z=-5.89, Nrf2 activator), ascorbic acid (z=-5.30), curcumin (z=-5.30), and luteolin (z=-4.31) (Figure 3, Table 2).

\subsection{Nutrient Pharmacokinetics}
Comparative PK profiling (Figure 4, Table 3) identified ascorbic acid and sulforaphane as highest-priority countermeasures. Ascorbic acid is actively transported across the BBB via SVCT2, achieving $\sim$10-fold higher brain vs. plasma concentrations \citep{Hoffer2020}. Sulforaphane crosses the BBB within 15 minutes and activates Nrf2/ARE \citep{Zheng2022}. Curcumin has a critical bioavailability limitation: unconjugated plasma levels remain $\sim$1000-fold below in vitro effective concentrations \citep{Kroon2025}.

\subsection{Intervention Network}
A tripartite network (Figure 6) maps 7 nutrients to 5 target pathways and 4 protective mechanisms, revealing complementary multi-target coverage.

\subsection{Dietary Strategy}
Twelve curated vegan recipes (Figure 7, 8, Table 5) provide phased nutrient coverage across pre-flight, in-flight, and post-flight mission phases.

\section{Discussion}
The brain transcriptomic signature reveals a coherent pattern of mitochondrial energy failure, impaired protein homeostasis, and DNA repair suppression, consistent with the mitochondrial stress hub model \citep{daSilveira2020,Afshinnekoo2020}. The compensatory upregulation of neuronal signaling pathways may reflect adaptive plasticity but could predispose to excitotoxicity given impaired mitochondrial function.

The identification of sulforaphane and ascorbic acid as top nutrient reversers with favorable PK profiles provides a practical intervention strategy. Sulforaphane's Nrf2/ARE activation directly addresses the oxidative stress and mitochondrial dysfunction central to the signature, while ascorbic acid's active BBB transport ensures reliable brain accumulation.

The curcumin bioavailability limitation, highlighted by the 2025 critical reappraisal \citep{Kroon2025}, underscores the importance of PK-grounded nutrient selection. Mechanistic evidence alone is insufficient; brain-achievable concentrations must be confirmed.

\section{Limitations}
This analysis is based on rodent data; cross-species translation requires validation. PK data are from Earth-based studies and may not reflect spaceflight physiology. LINCS profiles cell line responses, not in vivo brain pharmacology. Dietary recommendations require validation in spaceflight analog studies.

\section{Conclusions}
Spaceflight induces a brain transcriptomic signature dominated by mitochondrial dysfunction and protein homeostasis failure. Seven vegan nutrients target these pathways through complementary mechanisms. Ascorbic acid and sulforaphane are the highest-priority countermeasures based on BBB penetration and brain concentration data. A phased dietary strategy provides practical implementation guidance for long-duration spaceflight.

\section*{Acknowledgements}
Data analysis scripting, figure generation and manuscript drafting were assisted by Biomni (Phylo, Inc.), an AI agent platform.

\section*{Data Availability}
All scripts and data are available in the Zenodo package. Source data: NASA OSDR (OSD-525, OSD-564, OSD-612, OSD-613). LINCS L1000: NIH Common Fund. Pharmacokinetic data: published literature (see references).

\end{document}
"""

    with open(output_path, "w") as f:
        f.write(latex)
    print(f"  LaTeX saved: {output_path} ({len(latex)} chars)")
    return output_path


# ──────────────────────────────────────────────────────────
# README and CITATION
# ──────────────────────────────────────────────────────────
def build_readme_citation():
    print("\nBuilding README and CITATION...")
    readme_path = "/mnt/results/README_neurological.md"
    citation_path = "/mnt/results/CITATION_neurological.cff"

    readme = """# Neurological Countermeasures for Spaceflight

## A Transcriptomic-Driven, Diet-Based Neuroprotection Strategy

This package presents a neurological-focused reanalysis of rodent ISS spaceflight brain transcriptomic data, combined with LINCS L1000 drug connectivity mapping, nutrient pharmacokinetic profiling, and vegan dietary translation.

## Contents

### Reports
- `report_neurological_countermeasures.pdf` — Full PDF report (~20 pages)
- `manuscript_neurological_countermeasures.tex` — LaTeX manuscript

### Figures (results/figures/)
- `fig1_brain_volcano.svg/png` — Brain transcriptomic volcano plot
- `fig2_gsea_theme_dotplot.svg/png` — GSEA pathways by neurological theme
- `fig3_lincs_reversers_bar.svg/png` — Top 15 LINCS reversers
- `fig4_nutrient_pk_radar.svg/png` — Nutrient PK comparison radar
- `fig5_spaceflight_brain_mechanism.png` — Spaceflight brain injury cascade
- `fig6_nutrient_intervention_network.png` — Nutrient-pathway-gene network
- `fig7_diet_mission_phase.png` — Diet strategy by mission phase
- `fig8_recipe_nutrient_heatmap.svg/png` — Recipe nutrient coverage heatmap
- `figure_legends.md` — Detailed figure legends

### Tables (results/tables/)
- `brain_pathway_themes.csv` — 550 pathways in 10 neurological themes
- `brain_nutrient_pk_table.csv` — 7 nutrients × 16 PK columns
- `brain_gene_pathway_nutrient_network.csv` — 27-edge intervention network
- `brain_supplementary_tables/` — Tables S1-S6 (full signatures, GSEA, LINCS, ORA)

### Scripts (scripts/)
- `08_brain_neuro_analysis.py` — Pathway themes, PK table, network
- `09_neuro_figures.py` — Data-driven figures (1-4, 8)
- `10_neuro_report.py` — PDF report + LaTeX manuscript
- `11_neuro_zenodo.py` — Zenodo package assembly

## Key Findings

1. **Brain consensus signature**: 505 genes (208 up, 297 down, 13 core) from 4 rodent ISS studies
2. **Dominant pathology**: Mitochondrial dysfunction, protein homeostasis failure, DNA repair suppression
3. **Top nutrient reversers**: Sulforaphane (Nrf2 activator), Ascorbic acid (BBB transport), Quercetin (BBB integrity)
4. **Best PK profiles**: Ascorbic acid and Sulforaphane (confirmed BBB penetration, therapeutic brain concentrations)
5. **Critical caveat**: Curcumin bioavailability ~1000x below therapeutic (Kroon et al. 2025)

## Data Sources

- NASA OSDR: OSD-525, OSD-564, OSD-612, OSD-613 (rodent ISS brain RNA-seq)
- LINCS L1000: NIH Common Fund (~1.8M perturbational profiles)
- Broad Drug Repurposing Hub: Clinical phase and MOA annotations
- FooDB: Vegan food source mapping
- Published literature: Nutrient pharmacokinetic data

## Reproducibility

All analyses are reproducible from the provided scripts. Run in order:
```
python scripts/08_brain_neuro_analysis.py
python scripts/09_neuro_figures.py
python scripts/10_neuro_report.py
python scripts/11_neuro_zenodo.py
```

## Citation

See `CITATION_neurological.cff` for citation information.
"""

    with open(readme_path, "w") as f:
        f.write(readme)
    print(f"  README saved: {readme_path}")

    citation = """cff-version: 1.2.0
title: "Neurological Countermeasures for Spaceflight: A Transcriptomic-Driven, Diet-Based Neuroprotection Strategy"
message: "If you use this analysis, please cite as below."
type: software
authors:
  - given-names: Richard
    family-names: Barker
date-released: 2026-08-03
preferred-citation:
  type: software
  title: "Neurological Countermeasures for Spaceflight"
  authors:
    - given-names: Richard
      family-names: Barker
  year: 2026
  notes: "Generated by Biomni (Phylo). Analysis of NASA OSDR rodent ISS brain transcriptomic data with LINCS L1000 drug connectivity mapping and vegan dietary translation."
keywords:
  - spaceflight
  - neuroscience
  - transcriptomics
  - meta-analysis
  - LINCS L1000
  - drug repurposing
  - nutrition
  - neuroprotection
  - blood-brain barrier
  - mitochondrial dysfunction
"""

    with open(citation_path, "w") as f:
        f.write(citation)
    print(f"  CITATION saved: {citation_path}")


# ──────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 60)
    print("Script 10: Neurological Report + Manuscript")
    print("=" * 60)

    pdf_path = build_pdf_report()
    tex_path = build_latex_manuscript()
    build_readme_citation()

    print("\n" + "=" * 60)
    print("Script 10 complete.")
    print(f"  PDF: {pdf_path}")
    print(f"  LaTeX: {tex_path}")
    print("=" * 60)
